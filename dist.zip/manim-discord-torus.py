from manim import *
from manim.opengl import *
import os
from pathlib import Path

config.renderer = "opengl"

def texture(frame):
  return (
    Path(os.path.realpath(__file__)).parent
    / "assets"
    / ("MainScene%04d.png" % frame)
  )

class OpenGLTorus(OpenGLSurface):
  def func(self, u, v):
    P = np.array([np.cos(u), np.sin(u), 0])
    return (self.R - self.r * np.cos(v)) * P - self.r * np.sin(v) * OUT

  def __init__(self, **kwargs):
    self.R = 4
    self.r = 1

    super().__init__(
      uv_func=self.func,
      u_range=(0, TAU),
      v_range=(0, TAU),
      resolution=(101, 101),
      **kwargs,
    )

def create_torus_surface(torus, frame):
  return OpenGLTexturedSurface(torus, texture(frame)).scale(0.8).set_opacity(0.7)

class AnimateTorusTexture(ThreeDScene):
  def construct(self):
    config.disable_caching = True

    torus = OpenGLTorus()
    frame = 0
    torus_surface = create_torus_surface(torus, frame)

    def replace_torus(dt):
      nonlocal torus_surface, frame
      new_surface = create_torus_surface(torus, frame)
      self.replace(torus_surface, new_surface)
      torus_surface = new_surface
      frame += 1

    trk = ValueTracker()
    self.add(torus_surface)
    self.add_updater(replace_torus)
    self.play(trk.animate.set_value(1), run_time=13)
    self.remove_updater(replace_torus)
